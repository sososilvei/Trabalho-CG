
Thank you for purchasing this space craft model by Mark W. Kirby

The mesh contains 2022 Polygons, 1 512 X 512 texure map, and a light map. 3DS, LWO, OBJ and MS3D formats are included. 

Because this is a purchased item, it may not be distributed in any editable or copiable form other than by use of the original purchaser.